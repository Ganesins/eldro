<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\eldro;

class EldroController extends Controller
{
    public function create(){
        return view('index');
    }
    public function store(Request $request){
         $request->validate([
            'name'=>'required|alpha',
            'email'=>'required|email',
        ]);
        $name=$request->input('name');
        $dob=$request->input('dob');
        $fname=$request->input('fname');
        $gender=$request->input('gender');
        $country=$request->input('country');
        $state=$request->input('state');
        $photo=$request->input('photo');
        $email=$request->input('email');
        $mobile=$request->input('mobile');
        $hobbi=$request->input('hobbi');
        $education=$request->input('education');

        $stu=new eldro;
        $stu->name=$name;
        $stu->dob=$dob;
        $stu->fname=$fname;
        $stu->gender=$gender;
        $stu->country=$country;
        $stu->state=$state;
        $stu->photo=$photo;
        $stu->eamil=$email;
        $stu->phonenumber=$mobile;
        $stu->hobbi=$hobbi;
        $stu->education=$education;
        $stu->save();

        return redirect('/');
    }
    public function list(){
        $stu=eldro::all();
        return view('list',['student'=>$stu]);
    }
    public function delete($id){
        $stu=eldro::find($id);
        $stu->delete();
        return redirect('list');
    }
    public function edit($id){
        $stu=eldro::find($id);
        return view('edit',['stu'=>$stu]);
    }
       public function update(Request $request,$id){
         
        $stu=eldro::find($id);
        $stu->name=$request->input('name');
        $stu->dob=$request->input('dob');
        $stu->fname=$request->input('fname');
        $stu->gender=$request->input('gender');
        $stu->country=$request->input('country');
        $stu->state=$request->input('state');
        $stu->photo=$request->input('photo');
        $stu->eamil=$request->input('email');
        $stu->phonenumber=$request->input('mobile');
        $stu->hobbi=$request->input('hobbi');
        $stu->education=$request->input('education');

        $stu->save();
        return redirect('list');

    }


}
