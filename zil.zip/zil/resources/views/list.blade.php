<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>list</title>
</head>
<body>
	<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>list</title>
	<style>
		table,th,td{
			border-collapse: collapse;
		}
	</style>
</head>
<body>
	<h1>student List</h1>
	<table border="2">
		<tr>
			<th>Name</th>
			<th>Dob</th>
			<th>fname</th>
			<th>gender</th>
			<th>country</th>
			<th>state</th>
			<th>Email</th>
			<th>Phone</th>
			<th>hobbi</th>
			<th>education</th>
			<th>Edit</th>
			<th>Delete</th>
		</tr>
		@foreach($student as $stu)
		<tr>
			<th>{{$stu->name}}</th>
			<th>{{$stu->dob}}</th>
			<th>{{$stu->fname}}</th>
			<th>{{$stu->gender}}</th>
			<th>{{$stu->country}}</th>
			<th>{{$stu->state}}</th>
			<th>{{$stu->eamil}}</th>
			<th>{{$stu->phoneNumber}}</th>
			<th>{{$stu->hobbi}}</th>
			<th>{{$stu->education}}</th>
			<th><a href="edit/{{$stu->id}}">Edit</a></th>
			<th><a href="delete/{{$stu->id}}">Delete</a></th>

		</tr>
		@endforeach
	</table>
	<a href="/">Add More</a>

</body>
</html>

</body>
</html>