<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>edit</title>
</head>
<body>
	<h1>Edit</h1>
		<form method="post" action="{{ url('update/'.$stu->id)}}">
		@csrf
		Name:<input type="text" name="name" value="{{$stu->name}}"><br>
		Dob:<input type="date" name="dob" value="{{$stu->dob}}"><br>
		FatherName:<input type="text" name="fname" value="{{$stu->fname}}"><br>
		Gender:
		<input type="radio" id="male" name="gender" value="male">
<label for="html">male</label><br>
<input type="radio" id="female" name="gender" value="female">
<label for="css">female</label><br>
		country:<input type="text" name="country" value="{{$stu->country}}"
		><br>
		state:<input type="text" name="state" value="{{$stu->state}}"><br>
		photo:<input type="file" name="photo"><br>
		Emailid:<input type="email" name="email" value="{{$stu->email}}"><br>
		MobileNumber:<input type="text" name="mobile" value="{{$stu->phoneNumber}}"><br>
		Hobbies:<input type="check" name="hobbi" value="{{$stu->hobbi}}"><br>
		EducationalQlification:<input type="text" name="education" value="{{$stu->education}}">
		<a href="add more">Add more</a><br>
		<input type="submit" name="" value="save">

</form>

</body>
</html>