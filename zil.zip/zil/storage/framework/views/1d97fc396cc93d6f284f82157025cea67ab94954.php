<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>edit</title>
</head>
<body>
	<h1>Edit</h1>
		<form method="post" action="<?php echo e(url('update/'.$stu->id)); ?>">
		<?php echo csrf_field(); ?>
		Name:<input type="text" name="name" value="<?php echo e($stu->name); ?>"><br>
		Dob:<input type="date" name="dob" value="<?php echo e($stu->dob); ?>"><br>
		FatherName:<input type="text" name="fname" value="<?php echo e($stu->fname); ?>"><br>
		Gender:
		<input type="radio" id="male" name="gender" value="male">
<label for="html">male</label><br>
<input type="radio" id="female" name="gender" value="female">
<label for="css">female</label><br>
		country:<input type="text" name="country" value="<?php echo e($stu->country); ?>"
		><br>
		state:<input type="text" name="state" value="<?php echo e($stu->state); ?>"><br>
		photo:<input type="file" name="photo"><br>
		Emailid:<input type="email" name="email" value="<?php echo e($stu->email); ?>"><br>
		MobileNumber:<input type="text" name="mobile" value="<?php echo e($stu->phoneNumber); ?>"><br>
		Hobbies:<input type="check" name="hobbi" value="<?php echo e($stu->hobbi); ?>"><br>
		EducationalQlification:<input type="text" name="education" value="<?php echo e($stu->education); ?>">
		<a href="add more">Add more</a><br>
		<input type="submit" name="" value="save">

</form>

</body>
</html><?php /**PATH /home/ganesan/zil/resources/views/edit.blade.php ENDPATH**/ ?>