<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>list</title>
</head>
<body>
	<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>list</title>
	<style>
		table,th,td{
			border-collapse: collapse;
		}
	</style>
</head>
<body>
	<h1>student List</h1>
	<table border="2">
		<tr>
			<th>Name</th>
			<th>Dob</th>
			<th>fname</th>
			<th>gender</th>
			<th>country</th>
			<th>state</th>
			<th>Email</th>
			<th>Phone</th>
			<th>hobbi</th>
			<th>education</th>
			<th>Edit</th>
			<th>Delete</th>
		</tr>
		<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th><?php echo e($stu->name); ?></th>
			<th><?php echo e($stu->dob); ?></th>
			<th><?php echo e($stu->fname); ?></th>
			<th><?php echo e($stu->gender); ?></th>
			<th><?php echo e($stu->country); ?></th>
			<th><?php echo e($stu->state); ?></th>
			<th><?php echo e($stu->eamil); ?></th>
			<th><?php echo e($stu->phoneNumber); ?></th>
			<th><?php echo e($stu->hobbi); ?></th>
			<th><?php echo e($stu->education); ?></th>
			<th><a href="edit/<?php echo e($stu->id); ?>">Edit</a></th>
			<th><a href="delete/<?php echo e($stu->id); ?>">Delete</a></th>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="/">Add More</a>

</body>
</html>

</body>
</html><?php /**PATH /home/ganesan/zil/resources/views/list.blade.php ENDPATH**/ ?>