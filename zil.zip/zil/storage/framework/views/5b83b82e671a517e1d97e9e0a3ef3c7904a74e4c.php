<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style>
		span{color: red};
	</style>
</head>
<body>
	<form method="post" action="store">
		<?php echo csrf_field(); ?>
		Name:<input type="text" name="name"><br>
	<span><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
		Dob:<input type="date" name="dob"><br>
		FatherName:<input type="text" name="fname"><br>
		Gender:
		<input type="radio" id="male" name="gender" value="male">
<label for="html">male</label><br>
<input type="radio" id="female" name="gender" value="female">
<label for="css">female</label><br>
		country:<input type="text" name="country"><br>
		state:<input type="text" name="state"><br>
		photo:<input type="file" name="photo"><br>
		Emailid:<input type="email" name="email"><br>
			<span><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>

		MobileNumber:<input type="text" name="mobile"><br>
		Hobbies:<input type="check" name="hobbi"><br>
		EducationalQlification:<input type="text" name="education">
		<a href="add more">Add more</a><br>
		<input type="submit" name="" value="save">

</form>
<a href="list">View</a>

</body>
</html><?php /**PATH /home/ganesan/zil/resources/views/index.blade.php ENDPATH**/ ?>