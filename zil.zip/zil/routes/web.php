<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EldroController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// }); 
Route::get('/',[EldroController::class,'create']);
Route::post('store',[EldroController::class,'store']);
Route::get('list',[EldroController::class,'list']);
Route::get('delete/{id}',[EldroController::class,'delete']);
Route::get('edit/{id}',[EldroController::class,'edit']);
Route::post('update/{id}',[EldroController::class,'update']);



